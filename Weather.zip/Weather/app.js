document.addEventListener('DOMContentLoaded', () => {
    const locationInput = document.getElementById('locationInput');
    const getWeatherBtn = document.getElementById('getWeatherBtn');
    const unitToggle = document.getElementById('unitToggle');
    const weatherInfo = document.getElementById('weatherInfo');
    const errorInfo = document.getElementById('errorInfo');

    getWeatherBtn.addEventListener('click', () => {
        const location = locationInput.value.trim();
        const unit = unitToggle.value;

        if (location === '') {
            showError('Please enter a location.');
            return;
        }

        fetchWeather(location, unit);
    });

    if ('geolocation' in navigator) {
        const geolocationBtn = document.createElement('button');
        geolocationBtn.textContent = 'Use My Location';
        geolocationBtn.addEventListener('click', () => {
            getWeatherByGeolocation(unitToggle.value);
        });

        document.querySelector('.search-container').appendChild(geolocationBtn);
    }

    function fetchWeather(location, unit) {
        const apiKey = '436cb109c1d2f8dbf7cecadb2d455d56';
        const apiUrl = `https://api.openweathermap.org/data/2.5/weather?q=${location}&units=${unit}&appid=${apiKey}`;

        fetch(apiUrl)
            .then(response => {
                if (!response.ok) {
                    throw new Error('Weather data not found.');
                }
                return response.json();
            })
            .then(data => {
                displayWeather(data, unit);
            })
            .catch(error => {
                showError(`Error: ${error.message}`);
            });
    }

    function getWeatherByGeolocation(unit) {
        navigator.geolocation.getCurrentPosition(
            position => {
                const latitude = position.coords.latitude;
                const longitude = position.coords.longitude;
                const apiKey = '436cb109c1d2f8dbf7cecadb2d455d56';

                const apiUrl = `https://api.openweathermap.org/data/2.5/weather?lat=${latitude}&lon=${longitude}&units=${unit}&appid=${apiKey}`;

                fetch(apiUrl)
                    .then(response => {
                        if (!response.ok) {
                            throw new Error('Weather data not found.');
                        }
                        return response.json();
                    })
                    .then(data => {
                        displayWeather(data, unit);
                    })
                    .catch(error => {
                        showError(`Error: ${error.message}`);
                    });
            },
            error => {
                showError(`Geolocation error: ${error.message}`);
            }
        );
    }

    function displayWeather(data, unit) {
        const temperature = data.main.temp;
        const humidity = data.main.humidity;
        const windSpeed = data.wind.speed;
        const weatherDescription = data.weather[0].description;

        weatherInfo.innerHTML = `
            <h2>Weather in ${data.name}, ${data.sys.country}</h2>
            <p>Temperature: ${temperature}°${unit === 'metric' ? 'C' : 'F'}</p>
            <p>Humidity: ${humidity}%</p>
            <p>Wind Speed: ${windSpeed} m/s</p>
            <p>Weather Description: ${weatherDescription}</p>
        `;

        errorInfo.textContent = ''; // Clear any previous error messages
    }

    function showError(message) {
        errorInfo.textContent = message;
        weatherInfo.textContent = ''; // Clear weather info on error
    }
});